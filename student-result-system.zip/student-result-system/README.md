# Student Result System
## Super Easy Install Guide

================================================
  STEP 1: Database banao
================================================
1. XAMPP open karo
2. MySQL START karo (green)
3. Browser mein jao: http://localhost/phpmyadmin
4. Left mein "New" click karo
5. Name: student_result_db  -> Create

================================================
  STEP 2: Install karo (EASY WAY)
================================================
1. Yeh folder C:\xampp\htdocs\student-result-system mein rakho
2. INSTALL.bat file pe double-click karo
3. Wait karo 5-10 minute (PC slow hoga, normal hai)
4. "DONE! Everything installed" dikhne tak wait karo

================================================
  STEP 3: Server chalao
================================================
START-SERVER.bat pe double-click karo
phir browser mein: http://127.0.0.1:8000

================================================
  LOGIN CREDENTIALS
================================================
Admin:   admin@school.com   / password
Teacher: teacher@school.com / password
Student: student@school.com / password

================================================
  AGAR KOI ERROR AAY
================================================
Database Error:
  - MySQL XAMPP mein running hai?
  - student_result_db database bana hai?

Composer Error:
  - Internet connected hai?
  - Antivirus temporarily off karo

PC Hang hota hai:
  - Baaki sab programs band karo
  - INSTALL.bat dobara run karo
