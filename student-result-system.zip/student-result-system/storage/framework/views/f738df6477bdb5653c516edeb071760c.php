<?php $__env->startSection('content'); ?>
<div class="max-w-lg">
    <div class="mb-6">
        <h2 class="font-display text-xl font-semibold text-slate-800">Enter Marks</h2>
        <p class="text-sm text-slate-500 mt-0.5">Grade will be calculated automatically.</p>
    </div>

    
    <div class="card p-4 mb-5">
        <p class="text-xs font-medium text-slate-500 mb-2">Grade Scale</p>
        <div class="flex flex-wrap gap-2">
            <?php $__currentLoopData = ['A+' => ['90-100','emerald'], 'A' => ['80-89','green'], 'B' => ['70-79','blue'], 'C' => ['60-69','yellow'], 'D' => ['50-59','orange'], 'F' => ['<50','red']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade => [$range, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-<?php echo e($color); ?>-100 text-<?php echo e($color); ?>-700 font-medium">
                    <?php echo e($grade); ?> <span class="text-<?php echo e($color); ?>-500 font-normal"><?php echo e($range); ?>%</span>
                </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="card p-6">
        <form method="POST" action="<?php echo e(route('results.store')); ?>" novalidate>
            <?php echo csrf_field(); ?>
            <div class="space-y-4">
                <div>
                    <label class="form-label">Student</label>
                    <select name="student_id" class="form-input <?php echo e($errors->has('student_id') ? 'form-input-error' : ''); ?>" required>
                        <option value="">Select student…</option>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>" <?php echo e(old('student_id') == $s->id ? 'selected' : ''); ?>>
                                <?php echo e($s->user->name); ?> — <?php echo e($s->roll_number); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="form-label">Subject</label>
                    <select name="subject_id" id="subject_select" class="form-input <?php echo e($errors->has('subject_id') ? 'form-input-error' : ''); ?>" required>
                        <option value="">Select subject…</option>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>" data-total="<?php echo e($s->total_marks); ?>" <?php echo e(old('subject_id') == $s->id ? 'selected' : ''); ?>>
                                <?php echo e($s->name); ?> (<?php echo e($s->code); ?>) — Total: <?php echo e($s->total_marks); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Obtained Marks <span id="marks-hint" class="text-slate-400 font-normal">(max: —)</span></label>
                        <input type="number" name="obtained_marks" id="obtained_marks"
                               value="<?php echo e(old('obtained_marks')); ?>" min="0"
                               class="form-input <?php echo e($errors->has('obtained_marks') ? 'form-input-error' : ''); ?>"
                               oninput="calcGrade()" required>
                        <?php $__errorArgs = ['obtained_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        
                        <label class="form-label">Predicted Grade</label>
                        <div id="grade-preview" class="form-input text-center font-bold text-lg tracking-wide text-slate-300">—</div>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Exam Type</label>
                        <select name="exam_type" class="form-input" required>
                            <?php $__currentLoopData = ['midterm','final','quiz','assignment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t); ?>" <?php echo e(old('exam_type', 'final') == $t ? 'selected' : ''); ?>><?php echo e(ucfirst($t)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Session</label>
                        <select name="session" class="form-input" required>
                            <?php $__currentLoopData = ['2024-25','2023-24','2022-23']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sess); ?>" <?php echo e(old('session', '2024-25') == $sess ? 'selected' : ''); ?>><?php echo e($sess); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="flex gap-3 pt-2">
                    <button type="submit" class="btn-primary">Save & Calculate Grade</button>
                    <a href="<?php echo e(route('results.index')); ?>" class="btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
const subjectSelect = document.getElementById('subject_select');
const obtainedInput = document.getElementById('obtained_marks');
const gradePreview  = document.getElementById('grade-preview');
const marksHint     = document.getElementById('marks-hint');

function getTotal() {
    const opt = subjectSelect.options[subjectSelect.selectedIndex];
    return opt ? parseInt(opt.dataset.total || 0) : 0;
}

subjectSelect.addEventListener('change', () => {
    const t = getTotal();
    marksHint.textContent = t ? `(max: ${t})` : '(max: —)';
    obtainedInput.max = t || '';
    calcGrade();
});

function calcGrade() {
    const total = getTotal();
    const obtained = parseInt(obtainedInput.value);
    if (!total || isNaN(obtained) || obtained < 0) {
        gradePreview.textContent = '—';
        gradePreview.className = 'form-input text-center font-bold text-lg tracking-wide text-slate-300';
        return;
    }
    const pct = (obtained / total) * 100;
    let grade, cls;
    if (pct >= 90)      { grade = 'A+'; cls = 'text-emerald-600'; }
    else if (pct >= 80) { grade = 'A';  cls = 'text-green-600'; }
    else if (pct >= 70) { grade = 'B';  cls = 'text-blue-600'; }
    else if (pct >= 60) { grade = 'C';  cls = 'text-yellow-600'; }
    else if (pct >= 50) { grade = 'D';  cls = 'text-orange-500'; }
    else                { grade = 'F';  cls = 'text-red-600'; }
    gradePreview.textContent = `${grade} (${pct.toFixed(1)}%)`;
    gradePreview.className = `form-input text-center font-bold text-lg tracking-wide ${cls}`;
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\student-result-system\resources\views/results/create.blade.php ENDPATH**/ ?>