<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-6">
    <div>
        <h2 class="font-display text-xl font-semibold text-slate-800">Subjects</h2>
        <p class="text-sm text-slate-500 mt-0.5"><?php echo e($subjects->total()); ?> subjects</p>
    </div>
    <a href="<?php echo e(route('subjects.create')); ?>" class="btn-primary">
        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
        Add Subject
    </a>
</div>

<div class="card overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-slate-50">
                <tr>
                    <th class="table-th">Subject</th>
                    <th class="table-th">Code</th>
                    <th class="table-th">Class</th>
                    <th class="table-th">Total Marks</th>
                    <th class="table-th">Credit Hrs</th>
                    <th class="table-th">Results</th>
                    <th class="table-th text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="table-tr">
                    <td class="table-td font-medium text-slate-800"><?php echo e($subject->name); ?></td>
                    <td class="table-td font-mono text-xs"><?php echo e($subject->code); ?></td>
                    <td class="table-td"><?php echo e($subject->class); ?></td>
                    <td class="table-td"><?php echo e($subject->total_marks); ?></td>
                    <td class="table-td"><?php echo e($subject->credit_hours); ?></td>
                    <td class="table-td"><?php echo e($subject->results_count); ?></td>
                    <td class="table-td text-right">
                        <div class="flex items-center justify-end gap-2">
                            <a href="<?php echo e(route('subjects.edit', $subject)); ?>" class="text-xs text-slate-600 hover:text-slate-800 font-medium">Edit</a>
                            <form method="POST" action="<?php echo e(route('subjects.destroy', $subject)); ?>"
                                  onsubmit="return confirm('Delete this subject?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-xs text-red-500 hover:text-red-700 font-medium">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="table-td text-center text-slate-400 py-8">No subjects found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($subjects->hasPages()): ?>
        <div class="px-5 py-4 border-t border-slate-100"><?php echo e($subjects->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\student-result-system\resources\views/subjects/index.blade.php ENDPATH**/ ?>