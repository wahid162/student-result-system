
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Result Card — <?php echo e($student->user->name); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --navy:#0d1b2a; --navy2:#1b2e45; --gold:#c9a84c; --gold2:#e8c97a;
            --cream:#f8f4ec; --muted:#8a9ab0; --pass:#1db87a; --fail:#e05252; --warn:#e0943c;
        }
        body { background:#eef1f5; font-family:'DM Sans',sans-serif; min-height:100vh; display:flex; flex-direction:column; align-items:center; padding:40px 20px; }
        .action-bar { width:100%; max-width:860px; display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; }
        .back-link { display:inline-flex; align-items:center; gap:6px; font-size:13px; font-weight:500; color:var(--navy2); text-decoration:none; opacity:.7; transition:opacity .2s; }
        .back-link:hover { opacity:1; }
        .print-btn { display:inline-flex; align-items:center; gap:8px; padding:10px 22px; border-radius:8px; background:var(--navy); color:#fff; font-size:13px; font-weight:600; font-family:'DM Sans',sans-serif; border:none; cursor:pointer; letter-spacing:.4px; transition:background .2s,transform .15s; }
        .print-btn:hover { background:var(--navy2); transform:translateY(-1px); }
        .card { width:100%; max-width:860px; background:#fff; border-radius:20px; overflow:hidden; box-shadow:0 8px 48px rgba(13,27,42,.14),0 2px 8px rgba(13,27,42,.06); animation:rise .6s ease both; }
        @keyframes rise { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
        .header { background:var(--navy); padding:32px 40px 28px; position:relative; overflow:hidden; }
        .header::before { content:''; position:absolute; inset:0; background:radial-gradient(ellipse 60% 80% at 90% -10%,rgba(201,168,76,.18) 0%,transparent 60%),radial-gradient(ellipse 40% 60% at -5% 110%,rgba(201,168,76,.10) 0%,transparent 60%); }
        .header-inner { position:relative; display:flex; justify-content:space-between; align-items:flex-start; gap:20px; }
        .school-name { font-family:'Playfair Display',serif; font-size:22px; color:#fff; letter-spacing:.3px; }
        .school-sub { font-size:11px; color:var(--gold2); letter-spacing:2px; text-transform:uppercase; margin-top:4px; opacity:.85; }
        .doc-label { text-align:right; }
        .doc-title { font-family:'Playfair Display',serif; font-size:17px; color:var(--gold2); letter-spacing:.5px; }
        .doc-meta { font-size:11px; color:rgba(255,255,255,.5); margin-top:4px; font-family:'DM Mono',monospace; }
        .gold-line { height:2px; background:linear-gradient(90deg,transparent,var(--gold),transparent); margin:0 40px; opacity:.6; }
        .student-strip { padding:22px 40px; background:var(--cream); display:flex; gap:20px; align-items:center; }
        .avatar { width:54px; height:54px; border-radius:14px; background:var(--navy); color:var(--gold2); font-family:'Playfair Display',serif; font-size:22px; display:flex; align-items:center; justify-content:center; flex-shrink:0; box-shadow:0 4px 14px rgba(13,27,42,.2); }
        .info-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:0; flex:1; }
        .info-item { padding:4px 16px; border-right:1px solid rgba(13,27,42,.08); }
        .info-item:last-child { border-right:none; }
        .info-label { font-size:10px; letter-spacing:1.2px; text-transform:uppercase; color:var(--muted); font-weight:500; }
        .info-val { font-size:14px; font-weight:600; color:var(--navy); margin-top:3px; }
        .summary { display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:#e8edf3; }
        .summary-cell { background:#fff; padding:20px 24px; text-align:center; }
        .s-label { font-size:10px; letter-spacing:1.5px; text-transform:uppercase; color:var(--muted); font-weight:500; }
        .s-value { font-size:36px; font-family:'Playfair Display',serif; font-weight:700; line-height:1.1; margin:6px 0 2px; }
        .s-sub { font-size:11px; color:var(--muted); }
        .color-gold{color:var(--gold)} .color-navy{color:var(--navy)} .color-pass{color:var(--pass)} .color-fail{color:var(--fail)} .color-warn{color:var(--warn)}
        .table-wrap { padding:28px 40px; }
        .section-heading { font-size:10px; letter-spacing:2px; text-transform:uppercase; color:var(--muted); font-weight:600; margin-bottom:14px; }
        table { width:100%; border-collapse:collapse; font-size:13px; }
        thead tr { background:var(--navy); }
        th { padding:11px 14px; text-align:left; font-size:10px; letter-spacing:1.2px; text-transform:uppercase; color:rgba(255,255,255,.6); font-weight:600; }
        th:first-child { border-radius:8px 0 0 8px; } th:last-child { border-radius:0 8px 8px 0; }
        tbody tr { border-bottom:1px solid #f0f3f7; transition:background .15s; }
        tbody tr:hover { background:#f8fafc; } tbody tr:last-child { border-bottom:none; }
        td { padding:13px 14px; color:var(--navy); vertical-align:middle; }
        .td-num { font-size:11px; color:var(--muted); font-family:'DM Mono',monospace; }
        .td-subject { font-weight:600; }
        .td-code { font-family:'DM Mono',monospace; font-size:11px; color:var(--muted); }
        .td-marks { font-family:'DM Mono',monospace; font-weight:500; }
        .pbar-wrap { display:flex; align-items:center; gap:8px; }
        .pbar-bg { flex:1; height:5px; border-radius:99px; background:#e8edf3; max-width:56px; overflow:hidden; }
        .pbar-fill { height:100%; border-radius:99px; }
        .pbar-text { font-family:'DM Mono',monospace; font-size:12px; }
        .badge { display:inline-block; padding:3px 10px; border-radius:6px; font-size:12px; font-weight:700; letter-spacing:.5px; font-family:'DM Mono',monospace; }
        .grade-a-plus,.grade-a { background:#d1fae5; color:#065f46; }
        .grade-b-plus,.grade-b { background:#dbeafe; color:#1e40af; }
        .grade-c-plus,.grade-c { background:#fef9c3; color:#854d0e; }
        .grade-d { background:#ffedd5; color:#9a3412; }
        .grade-f { background:#fee2e2; color:#991b1b; }
        tfoot tr { background:var(--cream); }
        tfoot td { padding:12px 14px; font-size:12px; font-weight:700; color:var(--navy); border-top:2px solid #e0e7ef; }
        .card-footer { padding:16px 40px 24px; display:flex; justify-content:space-between; align-items:center; border-top:1px solid #f0f3f7; }
        .footer-stamp { display:flex; gap:8px; align-items:center; }
        .stamp-dot { width:8px; height:8px; border-radius:50%; background:var(--gold); }
        .footer-text { font-size:11px; color:var(--muted); }
        .footer-gen { font-size:11px; color:var(--muted); font-family:'DM Mono',monospace; }
        @media print {
            body { background:#fff; padding:0; }
            .action-bar { display:none; }
            .card { box-shadow:none; border-radius:0; max-width:100%; animation:none; }
            tbody tr:hover { background:transparent; }
        }
        @media (max-width:640px) {
            .header { padding:24px; } .header-inner { flex-direction:column; gap:8px; } .doc-label { text-align:left; }
            .student-strip { padding:18px 20px; flex-direction:column; align-items:flex-start; }
            .info-grid { grid-template-columns:repeat(2,1fr); gap:10px 0; } .info-item { border-right:none; }
            .table-wrap { padding:20px; } .card-footer { padding:14px 20px; flex-direction:column; gap:6px; } .gold-line { margin:0 20px; }
        }
    </style>
</head>
<body>

<div class="action-bar">
    <a href="<?php echo e(route('results.index')); ?>" class="back-link">
        <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.2"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>
        Back to Results
    </a>
    <button class="print-btn" onclick="window.print()">
        <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
        Print / Save PDF
    </button>
</div>

<div class="card">

    <div class="header">
        <div class="header-inner">
            <div>
                <div class="school-name">Student Result System</div>
                <div class="school-sub">Official Academic Record</div>
            </div>
            <div class="doc-label">
                <div class="doc-title">Result Card</div>
                <div class="doc-meta">Session 2024-25 &nbsp;·&nbsp; Final Exam</div>
            </div>
        </div>
    </div>
    <div class="gold-line"></div>

    <div class="student-strip">
        <div class="avatar"><?php echo e(strtoupper(substr($student->user->name, 0, 1))); ?></div>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Student Name</div>
                <div class="info-val"><?php echo e($student->user->name); ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Roll No.</div>
                <div class="info-val" style="font-family:'DM Mono',monospace"><?php echo e($student->roll_number); ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Class / Section</div>
                <div class="info-val"><?php echo e($student->class); ?><?php echo e($student->section ? ' / '.$student->section : ''); ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Email</div>
                <div class="info-val" style="font-size:12px;font-weight:500"><?php echo e($student->user->email); ?></div>
            </div>
        </div>
    </div>

    <?php $failed = $results->filter(fn($r) => $r->grade === 'F')->count(); ?>
    <div class="summary">
        <div class="summary-cell">
            <div class="s-label">Overall Score</div>
            <div class="s-value <?php echo e($overallPct >= 80 ? 'color-pass' : ($overallPct >= 60 ? 'color-navy' : ($overallPct >= 50 ? 'color-warn' : 'color-fail'))); ?>">
                <?php echo e($overallPct); ?><span style="font-size:18px">%</span>
            </div>
            <div class="s-sub"><?php echo e($results->sum('obtained_marks')); ?> / <?php echo e($results->sum('total_marks')); ?> marks</div>
        </div>
        <div class="summary-cell">
            <div class="s-label">CGPA</div>
            <div class="s-value color-navy"><?php echo e($cgpa); ?></div>
            <div class="s-sub">out of 4.0</div>
        </div>
        <div class="summary-cell">
            <div class="s-label">Final Status</div>
            <div class="s-value <?php echo e($failed == 0 ? 'color-pass' : 'color-fail'); ?>"><?php echo e($failed == 0 ? 'PASS' : 'FAIL'); ?></div>
            <?php if($failed > 0): ?>
                <div class="s-sub" style="color:var(--fail)"><?php echo e($failed); ?> subject(s) failed</div>
            <?php else: ?>
                <div class="s-sub">All subjects cleared</div>
            <?php endif; ?>
        </div>
    </div>

    <div class="table-wrap">
        <div class="section-heading">Subject-wise Result Breakdown</div>
        <?php if($results->count()): ?>
        <table>
            <thead>
                <tr>
                    <th>#</th><th>Subject</th><th>Code</th><th>Total</th>
                    <th>Obtained</th><th>Percentage</th><th>Grade</th><th>GPA</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="td-num"><?php echo e(str_pad($i+1,2,'0',STR_PAD_LEFT)); ?></td>
                    <td class="td-subject"><?php echo e($r->subject->name ?? '—'); ?></td>
                    <td class="td-code"><?php echo e($r->subject->code ?? '—'); ?></td>
                    <td class="td-marks"><?php echo e($r->total_marks); ?></td>
                    <td class="td-marks" style="font-weight:700"><?php echo e($r->obtained_marks); ?></td>
                    <td>
                        <div class="pbar-wrap">
                            <div class="pbar-bg">
                                <div class="pbar-fill" style="width:<?php echo e(min($r->percentage,100)); ?>%;background:<?php echo e($r->percentage >= 80 ? '#1db87a' : ($r->percentage >= 60 ? '#3b82f6' : ($r->percentage >= 50 ? '#e0943c' : '#e05252'))); ?>"></div>
                            </div>
                            <span class="pbar-text"><?php echo e($r->percentage); ?>%</span>
                        </div>
                    </td>
                    <td>
                        <?php
                            $g = $r->grade;
                            $cls = match($g) { 'A+'=>'grade-a-plus','A'=>'grade-a','B+'=>'grade-b-plus','B'=>'grade-b','C+'=>'grade-c-plus','C'=>'grade-c','D'=>'grade-d',default=>'grade-f' };
                        ?>
                        <span class="badge <?php echo e($cls); ?>"><?php echo e($g); ?></span>
                    </td>
                    <td class="td-marks"><?php echo e($r->gpa); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3">Total / Average</td>
                    <td><?php echo e($results->sum('total_marks')); ?></td>
                    <td><?php echo e($results->sum('obtained_marks')); ?></td>
                    <td><?php echo e($overallPct); ?>%</td>
                    <td>—</td>
                    <td><?php echo e($cgpa); ?></td>
                </tr>
            </tfoot>
        </table>
        <?php else: ?>
        <div style="text-align:center;padding:48px 0;color:var(--muted)">
            <svg width="40" height="40" fill="none" viewBox="0 0 24 24" stroke="currentColor" style="margin:0 auto 12px;display:block;opacity:.3"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            <p style="font-size:14px">No results have been entered for this student yet.</p>
        </div>
        <?php endif; ?>
    </div>

    <div class="card-footer">
        <div class="footer-stamp">
            <div class="stamp-dot"></div>
            <span class="footer-text">Verified · Student Result System</span>
        </div>
        <div class="footer-gen">Generated <?php echo e(now()->format('d M Y, h:i A')); ?></div>
    </div>

</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\student-result-system\resources\views/results/report.blade.php ENDPATH**/ ?>