<?php $__env->startSection('content'); ?>
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
    <div>
        <h2 class="font-display text-xl font-semibold text-slate-800">Results</h2>
        <p class="text-sm text-slate-500 mt-0.5"><?php echo e($results->total()); ?> result records</p>
    </div>
    <a href="<?php echo e(route('results.create')); ?>" class="btn-primary">
        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
        Enter Marks
    </a>
</div>


<form method="GET" class="card p-4 mb-4 grid grid-cols-2 lg:grid-cols-4 gap-3">
    <select name="student_id" class="form-input">
        <option value="">All Students</option>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s->id); ?>" <?php echo e(request('student_id') == $s->id ? 'selected' : ''); ?>><?php echo e($s->user->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="subject_id" class="form-input">
        <option value="">All Subjects</option>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s->id); ?>" <?php echo e(request('subject_id') == $s->id ? 'selected' : ''); ?>><?php echo e($s->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="exam_type" class="form-input">
        <option value="">All Types</option>
        <?php $__currentLoopData = ['midterm','final','quiz','assignment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($t); ?>" <?php echo e(request('exam_type') == $t ? 'selected' : ''); ?>><?php echo e(ucfirst($t)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="session" class="form-input">
        <option value="">All Sessions</option>
        <?php $__currentLoopData = ['2024-25','2023-24','2022-23']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($sess); ?>" <?php echo e(request('session') == $sess ? 'selected' : ''); ?>><?php echo e($sess); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <div class="col-span-2 lg:col-span-4 flex gap-2">
        <button type="submit" class="btn-primary">Apply Filters</button>
        <?php if(request()->hasAny(['student_id','subject_id','exam_type','session'])): ?>
            <a href="<?php echo e(route('results.index')); ?>" class="btn-secondary">Clear</a>
        <?php endif; ?>
    </div>
</form>

<div class="card overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-slate-50">
                <tr>
                    <th class="table-th">Student</th>
                    <th class="table-th">Subject</th>
                    <th class="table-th">Marks</th>
                    <th class="table-th">%</th>
                    <th class="table-th">Grade</th>
                    <th class="table-th">GPA</th>
                    <th class="table-th">Type</th>
                    <th class="table-th">Session</th>
                    <th class="table-th text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="table-tr">
                    <td class="table-td font-medium"><?php echo e($r->student->user->name ?? '—'); ?></td>
                    <td class="table-td"><?php echo e($r->subject->name ?? '—'); ?></td>
                    <td class="table-td"><?php echo e($r->obtained_marks); ?>/<?php echo e($r->total_marks); ?></td>
                    <td class="table-td"><?php echo e($r->percentage); ?>%</td>
                    <td class="table-td">
                        <?php $g = $r->grade; ?>
                        <span class="badge-<?php echo e(strtolower(str_replace('+','-plus',$g))); ?>"><?php echo e($g); ?></span>
                    </td>
                    <td class="table-td"><?php echo e($r->gpa); ?></td>
                    <td class="table-td capitalize"><?php echo e($r->exam_type); ?></td>
                    <td class="table-td"><?php echo e($r->session); ?></td>
                    <td class="table-td text-right">
                        <div class="flex items-center justify-end gap-2">
                            <a href="<?php echo e(route('results.edit', $r)); ?>" class="text-xs text-slate-600 hover:text-slate-800 font-medium">Edit</a>
                            <form method="POST" action="<?php echo e(route('results.destroy', $r)); ?>"
                                  onsubmit="return confirm('Delete this result?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-xs text-red-500 hover:text-red-700 font-medium">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="9" class="table-td text-center text-slate-400 py-8">No results found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($results->hasPages()): ?>
        <div class="px-5 py-4 border-t border-slate-100"><?php echo e($results->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\student-result-system\resources\views/results/index.blade.php ENDPATH**/ ?>