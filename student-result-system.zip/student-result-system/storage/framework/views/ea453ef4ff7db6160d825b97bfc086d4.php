<?php $__env->startSection('content'); ?>
<div class="max-w-lg">
    <div class="mb-6">
        <h2 class="font-display text-xl font-semibold text-slate-800">Edit Result</h2>
        <p class="text-sm text-slate-500 mt-0.5">
            <?php echo e($result->student->user->name ?? '—'); ?> · <?php echo e($result->subject->name ?? '—'); ?>

        </p>
    </div>
    <div class="card p-6">
        <form method="POST" action="<?php echo e(route('results.update', $result)); ?>" novalidate>
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="space-y-4">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Obtained Marks <span class="text-slate-400">(max: <?php echo e($result->total_marks); ?>)</span></label>
                        <input type="number" name="obtained_marks" id="obtained_marks"
                               value="<?php echo e(old('obtained_marks', $result->obtained_marks)); ?>"
                               min="0" max="<?php echo e($result->total_marks); ?>"
                               class="form-input <?php echo e($errors->has('obtained_marks') ? 'form-input-error' : ''); ?>"
                               oninput="calcGrade(<?php echo e($result->total_marks); ?>)" required>
                        <?php $__errorArgs = ['obtained_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label class="form-label">Predicted Grade</label>
                        <div id="grade-preview" class="form-input text-center font-bold text-lg">
                            <?php echo e($result->grade); ?> (<?php echo e($result->percentage); ?>%)
                        </div>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Exam Type</label>
                        <select name="exam_type" class="form-input" required>
                            <?php $__currentLoopData = ['midterm','final','quiz','assignment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t); ?>" <?php echo e(old('exam_type', $result->exam_type) == $t ? 'selected' : ''); ?>><?php echo e(ucfirst($t)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Session</label>
                        <select name="session" class="form-input" required>
                            <?php $__currentLoopData = ['2024-25','2023-24','2022-23']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sess); ?>" <?php echo e(old('session', $result->session) == $sess ? 'selected' : ''); ?>><?php echo e($sess); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="submit" class="btn-primary">Update Result</button>
                    <a href="<?php echo e(route('results.index')); ?>" class="btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
function calcGrade(total) {
    const obtained = parseInt(document.getElementById('obtained_marks').value);
    const el = document.getElementById('grade-preview');
    if (isNaN(obtained) || obtained < 0) { el.textContent = '—'; return; }
    const pct = (obtained / total) * 100;
    let grade;
    if (pct >= 90) grade = 'A+';
    else if (pct >= 80) grade = 'A';
    else if (pct >= 70) grade = 'B';
    else if (pct >= 60) grade = 'C';
    else if (pct >= 50) grade = 'D';
    else grade = 'F';
    el.textContent = `${grade} (${pct.toFixed(1)}%)`;
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\student-result-system\resources\views/results/edit.blade.php ENDPATH**/ ?>