<?php $__env->startSection('content'); ?>
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
    <div>
        <h2 class="font-display text-xl font-semibold text-slate-800">Students</h2>
        <p class="text-sm text-slate-500 mt-0.5"><?php echo e($students->total()); ?> enrolled students</p>
    </div>
    <a href="<?php echo e(route('students.create')); ?>" class="btn-primary">
        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
        Add Student
    </a>
</div>


<form method="GET" class="card p-4 mb-4 flex flex-col sm:flex-row gap-3">
    <input type="text" name="search" value="<?php echo e(request('search')); ?>"
           placeholder="Search name or roll number…"
           class="form-input flex-1">
    <select name="class" class="form-input sm:w-40">
        <option value="">All Classes</option>
        <?php $__currentLoopData = ['9','10','11','12']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c); ?>" <?php echo e(request('class') == $c ? 'selected' : ''); ?>>Class <?php echo e($c); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button type="submit" class="btn-primary">Filter</button>
    <?php if(request()->hasAny(['search','class'])): ?>
        <a href="<?php echo e(route('students.index')); ?>" class="btn-secondary">Clear</a>
    <?php endif; ?>
</form>

<div class="card overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-slate-50">
                <tr>
                    <th class="table-th">Name</th>
                    <th class="table-th">Roll No.</th>
                    <th class="table-th">Class</th>
                    <th class="table-th">Section</th>
                    <th class="table-th">Phone</th>
                    <th class="table-th text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="table-tr">
                    <td class="table-td">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 text-xs font-bold flex-shrink-0">
                                <?php echo e(strtoupper(substr($student->user->name ?? '?', 0, 1))); ?>

                            </div>
                            <span class="font-medium text-slate-800"><?php echo e($student->user->name ?? '—'); ?></span>
                        </div>
                    </td>
                    <td class="table-td font-mono text-xs"><?php echo e($student->roll_number); ?></td>
                    <td class="table-td"><?php echo e($student->class); ?></td>
                    <td class="table-td"><?php echo e($student->section ?? '—'); ?></td>
                    <td class="table-td"><?php echo e($student->phone ?? '—'); ?></td>
                    <td class="table-td text-right">
                        <div class="flex items-center justify-end gap-2">
                            <a href="<?php echo e(route('results.student', $student)); ?>" class="text-xs text-primary-600 hover:text-primary-700 font-medium">Report</a>
                            <a href="<?php echo e(route('students.edit', $student)); ?>" class="text-xs text-slate-600 hover:text-slate-800 font-medium">Edit</a>
                            <form method="POST" action="<?php echo e(route('students.destroy', $student)); ?>"
                                  onsubmit="return confirm('Delete this student and all their data?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-xs text-red-500 hover:text-red-700 font-medium">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="table-td text-center text-slate-400 py-8">No students found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($students->hasPages()): ?>
        <div class="px-5 py-4 border-t border-slate-100">
            <?php echo e($students->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\student-result-system\resources\views/students/index.blade.php ENDPATH**/ ?>