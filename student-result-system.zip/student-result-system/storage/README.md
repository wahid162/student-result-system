This directory is used by Laravel for caching, sessions, and logs.
Run: php artisan storage:link
