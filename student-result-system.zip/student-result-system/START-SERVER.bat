@echo off
title Student Result System - Server
color 0A
cls
echo ================================================
echo   Student Result System
echo   Server starting...
echo ================================================
echo.
echo Open browser: http://127.0.0.1:8000
echo Login:  admin@school.com / password
echo.
echo Press Ctrl+C to stop server
echo.
php artisan serve
pause
