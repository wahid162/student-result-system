<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ResultController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\SubjectController;
use Illuminate\Support\Facades\Route;

// Login page - GET
Route::get('/', [AuthController::class, 'showLogin'])->name('login');
Route::get('/login', [AuthController::class, 'showLogin']);

// Login submit - POST
Route::post('/login', [AuthController::class, 'login'])->name('login.post')->middleware('throttle:10,1');

// Logout
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// All authenticated routes
Route::middleware('auth')->group(function () {

    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Results
    Route::get('/results', [ResultController::class, 'index'])->name('results.index');
    Route::get('/results/student/{student}', [ResultController::class, 'studentReport'])->name('results.student');

    // Teacher/Admin only
    Route::middleware('role:admin,teacher')->group(function () {
        Route::get('/results/create',           [ResultController::class, 'create'])->name('results.create');
        Route::post('/results',                 [ResultController::class, 'store'])->name('results.store');
        Route::get('/results/{result}/edit',    [ResultController::class, 'edit'])->name('results.edit');
        Route::put('/results/{result}',         [ResultController::class, 'update'])->name('results.update');
        Route::delete('/results/{result}',      [ResultController::class, 'destroy'])->name('results.destroy');

        Route::resource('students', StudentController::class);
        Route::resource('subjects', SubjectController::class);
    });

});
