@echo off
title Student Result System - Auto Install
color 0A
cls

echo ================================================
echo   Student Result System - Auto Installer
echo ================================================
echo.

:: Check if we're in right folder
if not exist "artisan" (
    echo ERROR: Wrong folder! 
    echo Please put this folder in C:\xampp\htdocs\student-result-system
    pause
    exit
)

echo [1/6] Setting memory limit for composer...
set COMPOSER_MEMORY_LIMIT=-1

echo [2/6] Installing PHP packages (this takes 3-5 mins, please wait)...
echo       Do NOT close this window!
echo.
composer install --no-dev --optimize-autoloader --no-interaction
if errorlevel 1 (
    echo.
    echo FAILED: composer install failed. Make sure internet is connected.
    pause
    exit
)

echo.
echo [3/6] Generating app key...
php artisan key:generate --force

echo.
echo [4/6] Running database migrations...
php artisan migrate --seed --force
if errorlevel 1 (
    echo.
    echo FAILED: Database error!
    echo Make sure:
    echo   1. XAMPP MySQL is running
    echo   2. Database 'student_result_db' exists in phpMyAdmin
    pause
    exit
)

echo.
echo [5/6] Installing frontend packages...
call npm install --prefer-offline

echo.
echo [6/6] Building CSS and JS...
call npm run build

echo.
echo ================================================
echo   DONE! Everything installed successfully!
echo ================================================
echo.
echo Now run: php artisan serve
echo Then open: http://127.0.0.1:8000
echo.
echo Login: admin@school.com / password
echo.
pause
