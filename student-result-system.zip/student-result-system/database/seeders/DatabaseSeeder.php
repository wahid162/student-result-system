<?php

namespace Database\Seeders;

use App\Models\Result;
use App\Models\Student;
use App\Models\Subject;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Admin
        $admin = User::create([
            'name'     => 'System Admin',
            'email'    => 'admin@school.com',
            'password' => Hash::make('password'),
            'role'     => 'admin',
        ]);

        // Teacher
        $teacher = User::create([
            'name'     => 'Mr. Ahmed Khan',
            'email'    => 'teacher@school.com',
            'password' => Hash::make('password'),
            'role'     => 'teacher',
        ]);

        // Students
        $studentUser = User::create([
            'name'     => 'Ali Hassan',
            'email'    => 'student@school.com',
            'password' => Hash::make('password'),
            'role'     => 'student',
        ]);
        $student = Student::create([
            'user_id'      => $studentUser->id,
            'roll_number'  => 'CS-2024-001',
            'class'        => '10',
            'section'      => 'A',
            'date_of_birth'=> '2006-05-15',
            'phone'        => '03001234567',
        ]);

        $studentUser2 = User::create([
            'name'     => 'Sara Malik',
            'email'    => 'sara@school.com',
            'password' => Hash::make('password'),
            'role'     => 'student',
        ]);
        $student2 = Student::create([
            'user_id'      => $studentUser2->id,
            'roll_number'  => 'CS-2024-002',
            'class'        => '10',
            'section'      => 'A',
            'date_of_birth'=> '2006-08-20',
            'phone'        => '03007654321',
        ]);

        // Subjects
        $subjects = [
            ['name' => 'Mathematics',      'code' => 'MATH-10', 'class' => '10', 'total_marks' => 100, 'credit_hours' => 4],
            ['name' => 'Physics',          'code' => 'PHY-10',  'class' => '10', 'total_marks' => 100, 'credit_hours' => 4],
            ['name' => 'Chemistry',        'code' => 'CHEM-10', 'class' => '10', 'total_marks' => 100, 'credit_hours' => 3],
            ['name' => 'English',          'code' => 'ENG-10',  'class' => '10', 'total_marks' => 100, 'credit_hours' => 3],
            ['name' => 'Computer Science', 'code' => 'CS-10',   'class' => '10', 'total_marks' => 100, 'credit_hours' => 3],
        ];

        $createdSubjects = [];
        foreach ($subjects as $s) {
            $createdSubjects[] = Subject::create($s);
        }

        // Sample results for student 1
        $marks1 = [95, 82, 74, 88, 91];
        foreach ($createdSubjects as $i => $subject) {
            Result::create([
                'student_id'     => $student->id,
                'subject_id'     => $subject->id,
                'teacher_id'     => $teacher->id,
                'obtained_marks' => $marks1[$i],
                'total_marks'    => 100,
                'exam_type'      => 'final',
                'session'        => '2024-25',
            ]);
        }

        // Sample results for student 2
        $marks2 = [65, 78, 55, 92, 48];
        foreach ($createdSubjects as $i => $subject) {
            Result::create([
                'student_id'     => $student2->id,
                'subject_id'     => $subject->id,
                'teacher_id'     => $teacher->id,
                'obtained_marks' => $marks2[$i],
                'total_marks'    => 100,
                'exam_type'      => 'final',
                'session'        => '2024-25',
            ]);
        }
    }
}
