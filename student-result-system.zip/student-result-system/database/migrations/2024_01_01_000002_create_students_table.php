<?php
// database/migrations/2024_01_01_000002_create_students_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('students', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('roll_number')->unique();
            $table->string('class');
            $table->string('section')->nullable();
            $table->date('date_of_birth')->nullable();
            $table->string('phone', 20)->nullable();
            $table->timestamps();
            $table->index(['class', 'section']);
        });
    }

    public function down(): void { Schema::dropIfExists('students'); }
};
