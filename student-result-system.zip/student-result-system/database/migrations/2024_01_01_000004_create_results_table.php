<?php
// database/migrations/2024_01_01_000004_create_results_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('results', function (Blueprint $table) {
            $table->id();
            $table->foreignId('student_id')->constrained()->cascadeOnDelete();
            $table->foreignId('subject_id')->constrained()->cascadeOnDelete();
            $table->foreignId('teacher_id')->constrained('users')->cascadeOnDelete();
            $table->unsignedSmallInteger('obtained_marks');
            $table->unsignedSmallInteger('total_marks');
            $table->enum('exam_type', ['midterm', 'final', 'quiz', 'assignment'])->default('final');
            $table->string('session', 20)->default('2024-25');
            $table->timestamps();

            $table->unique(['student_id', 'subject_id', 'exam_type', 'session']);
            $table->index(['student_id', 'session']);
        });
    }

    public function down(): void { Schema::dropIfExists('results'); }
};
