<?php
// database/migrations/2024_01_01_000003_create_subjects_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('subjects', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('code', 20)->unique();
            $table->string('class');
            $table->unsignedSmallInteger('total_marks')->default(100);
            $table->unsignedTinyInteger('credit_hours')->default(3);
            $table->timestamps();
            $table->index('class');
        });
    }

    public function down(): void { Schema::dropIfExists('subjects'); }
};
