<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Sign In — Student Result System</title>
    <meta name="robots" content="noindex">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Sora:wght@600;700&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <style>
        body { background: linear-gradient(135deg, #f0f4ff 0%, #e8f0fe 50%, #f5f3ff 100%); }
        .login-bg-circle {
            position: fixed; border-radius: 50%; filter: blur(60px); opacity: 0.4; pointer-events: none;
        }
    </style>
</head>
<body class="h-full flex items-center justify-center p-4" style="min-height:100vh">

    <!-- Background decorative circles -->
    <div class="login-bg-circle" style="width:400px;height:400px;background:#c7d2fe;top:-100px;right:-100px;animation:float 6s ease-in-out infinite;"></div>
    <div class="login-bg-circle" style="width:300px;height:300px;background:#ddd6fe;bottom:-80px;left:-80px;animation:float 8s ease-in-out infinite reverse;"></div>

<div class="w-full max-w-sm relative z-10">

    <!-- Logo -->
    <div class="text-center mb-8 animate-fade-in-up">
        <div class="inline-flex w-16 h-16 rounded-2xl bg-primary-600 items-center justify-center mb-4 animate-float shadow-lg shadow-primary-200">
            <svg class="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.966 8.966 0 00-6 2.292m0-14.25v14.25"/>
            </svg>
        </div>
        <h1 class="font-display text-2xl font-semibold text-slate-800">Student Result System</h1>
        <p class="text-sm text-slate-500 mt-1">Sign in to your account</p>
    </div>

    <!-- Card -->
    <div class="card p-6 animate-fade-in-up stagger-2" style="backdrop-filter:blur(10px)">
        <form method="POST" action="/login" novalidate>
            @csrf
            <div class="space-y-4">
                <div class="animate-fade-in-up stagger-3">
                    <label for="email" class="form-label">Email address</label>
                    <input type="email" id="email" name="email"
                           value="{{ old('email') }}"
                           autocomplete="email"
                           placeholder="admin@school.com"
                           class="form-input {{ $errors->has('email') ? 'form-input-error' : '' }}"
                           required autofocus>
                    @error('email')
                        <p class="mt-1 text-xs text-red-600 animate-fade-in">{{ $message }}</p>
                    @enderror
                </div>

                <div class="animate-fade-in-up stagger-4">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password"
                           autocomplete="current-password"
                           placeholder="••••••••"
                           class="form-input {{ $errors->has('password') ? 'form-input-error' : '' }}"
                           required>
                    @error('password')
                        <p class="mt-1 text-xs text-red-600 animate-fade-in">{{ $message }}</p>
                    @enderror
                </div>

                <div class="flex items-center animate-fade-in-up stagger-5">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="remember" class="rounded border-slate-300 text-primary-600">
                        <span class="text-sm text-slate-600">Remember me</span>
                    </label>
                </div>

                <div class="animate-fade-in-up stagger-6">
                    <button type="submit" class="btn-primary w-full justify-center py-2.5 text-base">
                        Sign In
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                        </svg>
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- Demo credentials -->
    <div class="mt-4 card p-4 animate-fade-in-up stagger-6">
        <p class="text-xs font-medium text-slate-500 mb-2">Demo credentials</p>
        <div class="space-y-1 text-xs text-slate-600">
            <div class="flex justify-between items-center py-1 border-b border-slate-50">
                <span class="inline-flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-primary-500 inline-block"></span>Admin</span>
                <span class="font-mono">admin@school.com / password</span>
            </div>
            <div class="flex justify-between items-center py-1 border-b border-slate-50">
                <span class="inline-flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>Teacher</span>
                <span class="font-mono">teacher@school.com / password</span>
            </div>
            <div class="flex justify-between items-center py-1">
                <span class="inline-flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-amber-500 inline-block"></span>Student</span>
                <span class="font-mono">student@school.com / password</span>
            </div>
        </div>
    </div>

</div>
</body>
</html>
