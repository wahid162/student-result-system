<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Report</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; font-size: 13px; color: #1e293b; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 12px; }
        th, td { border: 1px solid #cbd5e1; padding: 7px 10px; text-align: left; }
        th { background: #f1f5f9; font-weight: 600; }
        .header { text-align: center; margin-bottom: 20px; }
        .info-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 16px; border: 1px solid #e2e8f0; padding: 12px; border-radius: 6px; }
        .stat-row { display: flex; gap: 20px; margin-bottom: 16px; }
        .stat { border: 1px solid #e2e8f0; padding: 10px 20px; border-radius: 6px; text-align: center; }
        .footer { margin-top: 20px; text-align: center; font-size: 11px; color: #94a3b8; }
    </style>
</head>
<body>
    @yield('content')
</body>
</html>