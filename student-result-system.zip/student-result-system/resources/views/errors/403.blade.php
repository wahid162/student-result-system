<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 — Unauthorized</title>
    <meta name="robots" content="noindex">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    @vite(['resources/css/app.css'])
</head>
<body class="h-full bg-slate-50 flex items-center justify-center p-4">
<div class="text-center max-w-sm">
    <p class="text-6xl font-display font-bold text-primary-200 mb-4">403</p>
    <h1 class="text-xl font-semibold text-slate-800 mb-2">Access Denied</h1>
    <p class="text-sm text-slate-500 mb-6">You don't have permission to view this page.</p>
    <a href="{{ url()->previous() }}" class="btn-secondary mr-2">Go Back</a>
    <a href="{{ route('dashboard') }}" class="btn-primary">Dashboard</a>
</div>
</body>
</html>
