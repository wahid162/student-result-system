@extends('layouts.app')
@section('content')
<div class="flex items-center justify-between mb-6">
    <div>
        <h2 class="font-display text-xl font-semibold text-slate-800">Subjects</h2>
        <p class="text-sm text-slate-500 mt-0.5">{{ $subjects->total() }} subjects</p>
    </div>
    <a href="{{ route('subjects.create') }}" class="btn-primary">
        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
        Add Subject
    </a>
</div>

<div class="card overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-slate-50">
                <tr>
                    <th class="table-th">Subject</th>
                    <th class="table-th">Code</th>
                    <th class="table-th">Class</th>
                    <th class="table-th">Total Marks</th>
                    <th class="table-th">Credit Hrs</th>
                    <th class="table-th">Results</th>
                    <th class="table-th text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($subjects as $subject)
                <tr class="table-tr">
                    <td class="table-td font-medium text-slate-800">{{ $subject->name }}</td>
                    <td class="table-td font-mono text-xs">{{ $subject->code }}</td>
                    <td class="table-td">{{ $subject->class }}</td>
                    <td class="table-td">{{ $subject->total_marks }}</td>
                    <td class="table-td">{{ $subject->credit_hours }}</td>
                    <td class="table-td">{{ $subject->results_count }}</td>
                    <td class="table-td text-right">
                        <div class="flex items-center justify-end gap-2">
                            <a href="{{ route('subjects.edit', $subject) }}" class="text-xs text-slate-600 hover:text-slate-800 font-medium">Edit</a>
                            <form method="POST" action="{{ route('subjects.destroy', $subject) }}"
                                  onsubmit="return confirm('Delete this subject?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-xs text-red-500 hover:text-red-700 font-medium">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                    <tr><td colspan="7" class="table-td text-center text-slate-400 py-8">No subjects found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($subjects->hasPages())
        <div class="px-5 py-4 border-t border-slate-100">{{ $subjects->links() }}</div>
    @endif
</div>
@endsection
