@extends('layouts.app')
@section('content')
<div class="max-w-md">
    <div class="mb-6">
        <h2 class="font-display text-xl font-semibold text-slate-800">Add Subject</h2>
    </div>
    <div class="card p-6">
        <form method="POST" action="{{ route('subjects.store') }}" novalidate>
            @csrf
            <div class="space-y-4">
                <div>
                    <label class="form-label">Subject Name</label>
                    <input type="text" name="name" value="{{ old('name') }}" class="form-input {{ $errors->has('name') ? 'form-input-error' : '' }}" required>
                    @error('name')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Subject Code</label>
                        <input type="text" name="code" value="{{ old('code') }}" placeholder="MATH-10" class="form-input {{ $errors->has('code') ? 'form-input-error' : '' }}" required>
                        @error('code')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="form-label">Class</label>
                        <select name="class" class="form-input" required>
                            <option value="">Select</option>
                            @foreach(['9','10','11','12'] as $c)
                                <option value="{{ $c }}" {{ old('class') == $c ? 'selected' : '' }}>Class {{ $c }}</option>
                            @endforeach
                        </select>
                        @error('class')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Total Marks</label>
                        <input type="number" name="total_marks" value="{{ old('total_marks', 100) }}" min="1" max="1000" class="form-input" required>
                    </div>
                    <div>
                        <label class="form-label">Credit Hours</label>
                        <input type="number" name="credit_hours" value="{{ old('credit_hours', 3) }}" min="1" max="10" class="form-input" required>
                    </div>
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="submit" class="btn-primary">Save Subject</button>
                    <a href="{{ route('subjects.index') }}" class="btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
