@extends('layouts.app')
@section('content')
<div class="max-w-md">
    <div class="mb-6">
        <h2 class="font-display text-xl font-semibold text-slate-800">Edit Subject</h2>
        <p class="text-sm text-slate-500 mt-0.5">{{ $subject->name }} · {{ $subject->code }}</p>
    </div>
    <div class="card p-6">
        <form method="POST" action="{{ route('subjects.update', $subject) }}" novalidate>
            @csrf @method('PUT')
            <div class="space-y-4">
                <div>
                    <label class="form-label">Subject Name</label>
                    <input type="text" name="name" value="{{ old('name', $subject->name) }}"
                           class="form-input {{ $errors->has('name') ? 'form-input-error' : '' }}" required>
                    @error('name')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Subject Code</label>
                        <input type="text" name="code" value="{{ old('code', $subject->code) }}"
                               class="form-input {{ $errors->has('code') ? 'form-input-error' : '' }}" required>
                        @error('code')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="form-label">Class</label>
                        <select name="class" class="form-input" required>
                            @foreach(['9','10','11','12'] as $c)
                                <option value="{{ $c }}" {{ old('class', $subject->class) == $c ? 'selected' : '' }}>
                                    Class {{ $c }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Total Marks</label>
                        <input type="number" name="total_marks" value="{{ old('total_marks', $subject->total_marks) }}"
                               min="1" max="1000" class="form-input" required>
                    </div>
                    <div>
                        <label class="form-label">Credit Hours</label>
                        <input type="number" name="credit_hours" value="{{ old('credit_hours', $subject->credit_hours) }}"
                               min="1" max="10" class="form-input" required>
                    </div>
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="submit" class="btn-primary">Update Subject</button>
                    <a href="{{ route('subjects.index') }}" class="btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
