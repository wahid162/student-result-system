@extends('layouts.app')
@section('content')
<div class="max-w-lg">
    <div class="mb-6">
        <h2 class="font-display text-xl font-semibold text-slate-800">Edit Student</h2>
        <p class="text-sm text-slate-500 mt-0.5">{{ $student->user->name }} · {{ $student->roll_number }}</p>
    </div>

    <div class="card p-6">
        <form method="POST" action="{{ route('students.update', $student) }}" novalidate>
            @csrf @method('PUT')
            <div class="space-y-4">
                <div>
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" value="{{ old('name', $student->user->name) }}" class="form-input {{ $errors->has('name') ? 'form-input-error' : '' }}" required>
                    @error('name')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Class</label>
                        <select name="class" class="form-input" required>
                            @foreach(['9','10','11','12'] as $c)
                                <option value="{{ $c }}" {{ old('class', $student->class) == $c ? 'selected' : '' }}>Class {{ $c }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Section</label>
                        <input type="text" name="section" value="{{ old('section', $student->section) }}" class="form-input">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Date of Birth</label>
                        <input type="date" name="date_of_birth" value="{{ old('date_of_birth', $student->date_of_birth) }}" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" value="{{ old('phone', $student->phone) }}" class="form-input">
                    </div>
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="submit" class="btn-primary">Update</button>
                    <a href="{{ route('students.index') }}" class="btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
