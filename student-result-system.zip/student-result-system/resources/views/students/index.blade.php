@extends('layouts.app')

@section('content')
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
    <div>
        <h2 class="font-display text-xl font-semibold text-slate-800">Students</h2>
        <p class="text-sm text-slate-500 mt-0.5">{{ $students->total() }} enrolled students</p>
    </div>
    <a href="{{ route('students.create') }}" class="btn-primary">
        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
        Add Student
    </a>
</div>

{{-- Filters --}}
<form method="GET" class="card p-4 mb-4 flex flex-col sm:flex-row gap-3">
    <input type="text" name="search" value="{{ request('search') }}"
           placeholder="Search name or roll number…"
           class="form-input flex-1">
    <select name="class" class="form-input sm:w-40">
        <option value="">All Classes</option>
        @foreach(['9','10','11','12'] as $c)
            <option value="{{ $c }}" {{ request('class') == $c ? 'selected' : '' }}>Class {{ $c }}</option>
        @endforeach
    </select>
    <button type="submit" class="btn-primary">Filter</button>
    @if(request()->hasAny(['search','class']))
        <a href="{{ route('students.index') }}" class="btn-secondary">Clear</a>
    @endif
</form>

<div class="card overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-slate-50">
                <tr>
                    <th class="table-th">Name</th>
                    <th class="table-th">Roll No.</th>
                    <th class="table-th">Class</th>
                    <th class="table-th">Section</th>
                    <th class="table-th">Phone</th>
                    <th class="table-th text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($students as $student)
                <tr class="table-tr">
                    <td class="table-td">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 text-xs font-bold flex-shrink-0">
                                {{ strtoupper(substr($student->user->name ?? '?', 0, 1)) }}
                            </div>
                            <span class="font-medium text-slate-800">{{ $student->user->name ?? '—' }}</span>
                        </div>
                    </td>
                    <td class="table-td font-mono text-xs">{{ $student->roll_number }}</td>
                    <td class="table-td">{{ $student->class }}</td>
                    <td class="table-td">{{ $student->section ?? '—' }}</td>
                    <td class="table-td">{{ $student->phone ?? '—' }}</td>
                    <td class="table-td text-right">
                        <div class="flex items-center justify-end gap-2">
                            <a href="{{ route('results.student', $student) }}" class="text-xs text-primary-600 hover:text-primary-700 font-medium">Report</a>
                            <a href="{{ route('students.edit', $student) }}" class="text-xs text-slate-600 hover:text-slate-800 font-medium">Edit</a>
                            <form method="POST" action="{{ route('students.destroy', $student) }}"
                                  onsubmit="return confirm('Delete this student and all their data?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-xs text-red-500 hover:text-red-700 font-medium">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                    <tr><td colspan="6" class="table-td text-center text-slate-400 py-8">No students found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($students->hasPages())
        <div class="px-5 py-4 border-t border-slate-100">
            {{ $students->links() }}
        </div>
    @endif
</div>
@endsection
