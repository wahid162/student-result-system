@extends('layouts.app')
@section('content')
<div class="max-w-lg">
    <div class="mb-6">
        <h2 class="font-display text-xl font-semibold text-slate-800">Add New Student</h2>
        <p class="text-sm text-slate-500 mt-0.5">Create a student account with login credentials.</p>
    </div>

    <div class="card p-6">
        <form method="POST" action="{{ route('students.store') }}" novalidate>
            @csrf
            <div class="space-y-4">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" value="{{ old('name') }}" class="form-input {{ $errors->has('name') ? 'form-input-error' : '' }}" required>
                        @error('name')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="form-label">Email</label>
                        <input type="email" name="email" value="{{ old('email') }}" class="form-input {{ $errors->has('email') ? 'form-input-error' : '' }}" required>
                        @error('email')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                    </div>
                </div>
                <div>
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-input {{ $errors->has('password') ? 'form-input-error' : '' }}" required minlength="6">
                    @error('password')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="form-label">Roll Number</label>
                        <input type="text" name="roll_number" value="{{ old('roll_number') }}" class="form-input {{ $errors->has('roll_number') ? 'form-input-error' : '' }}" required>
                        @error('roll_number')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="form-label">Class</label>
                        <select name="class" class="form-input {{ $errors->has('class') ? 'form-input-error' : '' }}" required>
                            <option value="">Select</option>
                            @foreach(['9','10','11','12'] as $c)
                                <option value="{{ $c }}" {{ old('class') == $c ? 'selected' : '' }}>Class {{ $c }}</option>
                            @endforeach
                        </select>
                        @error('class')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="form-label">Section</label>
                        <input type="text" name="section" value="{{ old('section') }}" placeholder="A" class="form-input">
                    </div>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Date of Birth</label>
                        <input type="date" name="date_of_birth" value="{{ old('date_of_birth') }}" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" value="{{ old('phone') }}" placeholder="03001234567" class="form-input">
                    </div>
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="submit" class="btn-primary">Save Student</button>
                    <a href="{{ route('students.index') }}" class="btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
