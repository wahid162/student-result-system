@extends('layouts.app')

@section('content')

@if(auth()->user()->isStudent())
<div class="mb-6 animate-fade-in-up">
    <h2 class="font-display text-xl font-semibold text-slate-800">My Academic Overview</h2>
    <p class="text-sm text-slate-500 mt-0.5">Session 2024-25 · Final Exams</p>
</div>

<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    @php $sCards = [
        ['label'=>'Subjects',  'value'=>$totalSubjects,           'color'=>'text-blue-600',   'bg'=>'bg-blue-50',   'delay'=>'0.05s'],
        ['label'=>'Average %', 'value'=>$avgPct.'%',              'color'=>'text-indigo-600', 'bg'=>'bg-indigo-50', 'delay'=>'0.10s'],
        ['label'=>'Passed',    'value'=>$passed,                  'color'=>'text-emerald-600','bg'=>'bg-emerald-50','delay'=>'0.15s'],
        ['label'=>'Failed',    'value'=>$totalSubjects - $passed, 'color'=>'text-red-600',    'bg'=>'bg-red-50',    'delay'=>'0.20s'],
    ]; @endphp
    @foreach($sCards as $s)
        <div class="card p-4 card-hover animate-scale-in" style="animation-delay:{{ $s['delay'] }}">
            <p class="text-xs text-slate-500 mb-1">{{ $s['label'] }}</p>
            <p class="text-3xl font-semibold {{ $s['color'] }}">{{ $s['value'] }}</p>
        </div>
    @endforeach
</div>

@if($results->count())
<div class="card overflow-hidden animate-fade-in-up stagger-3">
    <div class="px-5 py-4 border-b border-slate-100">
        <h3 class="font-medium text-slate-800 text-sm">My Results</h3>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-slate-50">
                <tr>
                    <th class="table-th">Subject</th>
                    <th class="table-th">Marks</th>
                    <th class="table-th">Percentage</th>
                    <th class="table-th">Grade</th>
                    <th class="table-th">GPA</th>
                </tr>
            </thead>
            <tbody>
                @foreach($results as $result)
                <tr class="table-tr">
                    <td class="table-td font-medium">{{ $result->subject->name }}</td>
                    <td class="table-td">{{ $result->obtained_marks }}/{{ $result->total_marks }}</td>
                    <td class="table-td">
                        <div class="flex items-center gap-2">
                            <div class="flex-1 bg-slate-100 rounded-full h-1.5 max-w-[80px] overflow-hidden">
                                <div class="h-1.5 rounded-full bg-primary-500 animate-progress" data-width="{{ $result->percentage }}" style="width:0%"></div>
                            </div>
                            <span>{{ $result->percentage }}%</span>
                        </div>
                    </td>
                    <td class="table-td">
                        @php $g = $result->grade; @endphp
                        <span class="badge-{{ strtolower(str_replace('+','-plus',$g)) }} animate-bounce-in">{{ $g }}</span>
                    </td>
                    <td class="table-td">{{ $result->gpa }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@else
    <div class="card p-10 text-center text-slate-400 text-sm animate-fade-in">No results available yet.</div>
@endif

@else
{{-- Admin/Teacher Dashboard --}}
<div class="mb-6 animate-fade-in-up">
    <h2 class="font-display text-xl font-semibold text-slate-800">Dashboard</h2>
    <p class="text-sm text-slate-500 mt-0.5">Welcome back, {{ auth()->user()->name }} 👋</p>
</div>

<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    @php $cards = [
        ['label'=>'Total Students',  'value'=>$totalStudents, 'color'=>'text-blue-600',   'bg'=>'bg-blue-50',   'delay'=>'0.05s'],
        ['label'=>'Subjects',         'value'=>$totalSubjects, 'color'=>'text-violet-600', 'bg'=>'bg-violet-50', 'delay'=>'0.10s'],
        ['label'=>'Results Entered',  'value'=>$totalResults,  'color'=>'text-emerald-600','bg'=>'bg-emerald-50','delay'=>'0.15s'],
        ['label'=>'Teachers',         'value'=>$totalTeachers, 'color'=>'text-amber-600',  'bg'=>'bg-amber-50',  'delay'=>'0.20s'],
    ]; @endphp
    @foreach($cards as $c)
        <div class="card p-4 card-hover animate-scale-in" style="animation-delay:{{ $c['delay'] }}">
            <p class="text-xs text-slate-500 mb-1">{{ $c['label'] }}</p>
            <p class="text-3xl font-semibold {{ $c['color'] }} count-up" data-target="{{ $c['value'] }}">{{ $c['value'] }}</p>
        </div>
    @endforeach
</div>

<!-- Quick actions -->
<div class="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
    @php $actions = [
        ['href'=>route('results.create'), 'label'=>'Enter Marks',  'sub'=>'Add new result',    'bg'=>'bg-primary-100', 'ic'=>'text-primary-600', 'path'=>'M12 4v16m8-8H4', 'delay'=>'0.1s'],
        ['href'=>route('students.create'),'label'=>'Add Student',  'sub'=>'Enroll new student','bg'=>'bg-emerald-100', 'ic'=>'text-emerald-600','path'=>'M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z','delay'=>'0.15s'],
        ['href'=>route('subjects.create'),'label'=>'Add Subject',  'sub'=>'Create new subject','bg'=>'bg-amber-100',   'ic'=>'text-amber-600',  'path'=>'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253','delay'=>'0.20s'],
    ]; @endphp
    @foreach($actions as $a)
        <a href="{{ $a['href'] }}" class="card p-4 card-hover flex items-center gap-3 animate-fade-in-up" style="animation-delay:{{ $a['delay'] }}">
            <div class="w-9 h-9 rounded-lg {{ $a['bg'] }} flex items-center justify-center flex-shrink-0">
                <svg class="w-4 h-4 {{ $a['ic'] }}" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="{{ $a['path'] }}"/>
                </svg>
            </div>
            <div>
                <p class="text-sm font-medium text-slate-800">{{ $a['label'] }}</p>
                <p class="text-xs text-slate-500">{{ $a['sub'] }}</p>
            </div>
        </a>
    @endforeach
</div>

<!-- Recent Results -->
<div class="card overflow-hidden animate-fade-in-up stagger-4">
    <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
        <h3 class="font-medium text-slate-800 text-sm">Recent Results</h3>
        <a href="{{ route('results.index') }}" class="text-xs text-primary-600 hover:text-primary-700 font-medium transition-colors">View all →</a>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-slate-50">
                <tr>
                    <th class="table-th">Student</th>
                    <th class="table-th">Subject</th>
                    <th class="table-th">Marks</th>
                    <th class="table-th">Grade</th>
                    <th class="table-th">Type</th>
                </tr>
            </thead>
            <tbody>
                @forelse($recentResults as $r)
                <tr class="table-tr">
                    <td class="table-td font-medium">{{ $r->student->user->name ?? '—' }}</td>
                    <td class="table-td">{{ $r->subject->name ?? '—' }}</td>
                    <td class="table-td">{{ $r->obtained_marks }}/{{ $r->total_marks }}</td>
                    <td class="table-td">
                        @php $g = $r->grade; @endphp
                        <span class="badge-{{ strtolower(str_replace('+','-plus',$g)) }}">{{ $g }}</span>
                    </td>
                    <td class="table-td capitalize">{{ $r->exam_type }}</td>
                </tr>
                @empty
                    <tr><td colspan="5" class="table-td text-center text-slate-400 py-8">No results yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endif

@endsection
