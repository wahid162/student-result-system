@extends('layouts.app')
@section('content')
<div class="max-w-lg">
    <div class="mb-6">
        <h2 class="font-display text-xl font-semibold text-slate-800">Enter Marks</h2>
        <p class="text-sm text-slate-500 mt-0.5">Grade will be calculated automatically.</p>
    </div>

    {{-- Grade scale reference --}}
    <div class="card p-4 mb-5">
        <p class="text-xs font-medium text-slate-500 mb-2">Grade Scale</p>
        <div class="flex flex-wrap gap-2">
            @foreach(['A+' => ['90-100','emerald'], 'A' => ['80-89','green'], 'B' => ['70-79','blue'], 'C' => ['60-69','yellow'], 'D' => ['50-59','orange'], 'F' => ['<50','red']] as $grade => [$range, $color])
                <span class="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-{{ $color }}-100 text-{{ $color }}-700 font-medium">
                    {{ $grade }} <span class="text-{{ $color }}-500 font-normal">{{ $range }}%</span>
                </span>
            @endforeach
        </div>
    </div>

    <div class="card p-6">
        <form method="POST" action="{{ route('results.store') }}" novalidate>
            @csrf
            <div class="space-y-4">
                <div>
                    <label class="form-label">Student</label>
                    <select name="student_id" class="form-input {{ $errors->has('student_id') ? 'form-input-error' : '' }}" required>
                        <option value="">Select student…</option>
                        @foreach($students as $s)
                            <option value="{{ $s->id }}" {{ old('student_id') == $s->id ? 'selected' : '' }}>
                                {{ $s->user->name }} — {{ $s->roll_number }}
                            </option>
                        @endforeach
                    </select>
                    @error('student_id')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                </div>

                <div>
                    <label class="form-label">Subject</label>
                    <select name="subject_id" id="subject_select" class="form-input {{ $errors->has('subject_id') ? 'form-input-error' : '' }}" required>
                        <option value="">Select subject…</option>
                        @foreach($subjects as $s)
                            <option value="{{ $s->id }}" data-total="{{ $s->total_marks }}" {{ old('subject_id') == $s->id ? 'selected' : '' }}>
                                {{ $s->name }} ({{ $s->code }}) — Total: {{ $s->total_marks }}
                            </option>
                        @endforeach
                    </select>
                    @error('subject_id')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Obtained Marks <span id="marks-hint" class="text-slate-400 font-normal">(max: —)</span></label>
                        <input type="number" name="obtained_marks" id="obtained_marks"
                               value="{{ old('obtained_marks') }}" min="0"
                               class="form-input {{ $errors->has('obtained_marks') ? 'form-input-error' : '' }}"
                               oninput="calcGrade()" required>
                        @error('obtained_marks')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        {{-- Live grade preview --}}
                        <label class="form-label">Predicted Grade</label>
                        <div id="grade-preview" class="form-input text-center font-bold text-lg tracking-wide text-slate-300">—</div>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Exam Type</label>
                        <select name="exam_type" class="form-input" required>
                            @foreach(['midterm','final','quiz','assignment'] as $t)
                                <option value="{{ $t }}" {{ old('exam_type', 'final') == $t ? 'selected' : '' }}>{{ ucfirst($t) }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Session</label>
                        <select name="session" class="form-input" required>
                            @foreach(['2024-25','2023-24','2022-23'] as $sess)
                                <option value="{{ $sess }}" {{ old('session', '2024-25') == $sess ? 'selected' : '' }}>{{ $sess }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div class="flex gap-3 pt-2">
                    <button type="submit" class="btn-primary">Save & Calculate Grade</button>
                    <a href="{{ route('results.index') }}" class="btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
const subjectSelect = document.getElementById('subject_select');
const obtainedInput = document.getElementById('obtained_marks');
const gradePreview  = document.getElementById('grade-preview');
const marksHint     = document.getElementById('marks-hint');

function getTotal() {
    const opt = subjectSelect.options[subjectSelect.selectedIndex];
    return opt ? parseInt(opt.dataset.total || 0) : 0;
}

subjectSelect.addEventListener('change', () => {
    const t = getTotal();
    marksHint.textContent = t ? `(max: ${t})` : '(max: —)';
    obtainedInput.max = t || '';
    calcGrade();
});

function calcGrade() {
    const total = getTotal();
    const obtained = parseInt(obtainedInput.value);
    if (!total || isNaN(obtained) || obtained < 0) {
        gradePreview.textContent = '—';
        gradePreview.className = 'form-input text-center font-bold text-lg tracking-wide text-slate-300';
        return;
    }
    const pct = (obtained / total) * 100;
    let grade, cls;
    if (pct >= 90)      { grade = 'A+'; cls = 'text-emerald-600'; }
    else if (pct >= 80) { grade = 'A';  cls = 'text-green-600'; }
    else if (pct >= 70) { grade = 'B';  cls = 'text-blue-600'; }
    else if (pct >= 60) { grade = 'C';  cls = 'text-yellow-600'; }
    else if (pct >= 50) { grade = 'D';  cls = 'text-orange-500'; }
    else                { grade = 'F';  cls = 'text-red-600'; }
    gradePreview.textContent = `${grade} (${pct.toFixed(1)}%)`;
    gradePreview.className = `form-input text-center font-bold text-lg tracking-wide ${cls}`;
}
</script>
@endsection
