@extends('layouts.app')
@section('content')

<div class="mb-6">
    <h2 class="font-display text-xl font-semibold text-slate-800">My Results</h2>
    <p class="text-sm text-slate-500 mt-0.5">Your exam results and grades</p>
</div>

@if($results->count())
<div class="card overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-slate-50">
                <tr>
                    <th class="table-th">Subject</th>
                    <th class="table-th">Exam Type</th>
                    <th class="table-th">Session</th>
                    <th class="table-th">Marks</th>
                    <th class="table-th">Percentage</th>
                    <th class="table-th">Grade</th>
                    <th class="table-th">GPA</th>
                </tr>
            </thead>
            <tbody>
                @foreach($results as $r)
                <tr class="table-tr">
                    <td class="table-td font-medium text-slate-800">{{ $r->subject->name ?? '—' }}</td>
                    <td class="table-td capitalize">{{ $r->exam_type }}</td>
                    <td class="table-td">{{ $r->session }}</td>
                    <td class="table-td">{{ $r->obtained_marks }}/{{ $r->total_marks }}</td>
                    <td class="table-td">
                        <div class="flex items-center gap-2">
                            <div class="w-16 bg-slate-100 rounded-full h-1.5">
                                <div class="h-1.5 rounded-full
                                    {{ $r->percentage >= 80 ? 'bg-emerald-500' : ($r->percentage >= 60 ? 'bg-blue-500' : ($r->percentage >= 50 ? 'bg-orange-400' : 'bg-red-500')) }}"
                                    style="width:{{ min($r->percentage,100) }}%"></div>
                            </div>
                            <span>{{ $r->percentage }}%</span>
                        </div>
                    </td>
                    <td class="table-td">
                        @php $g = $r->grade; @endphp
                        <span class="badge-{{ strtolower(str_replace('+','-plus',$g)) }}">{{ $g }}</span>
                    </td>
                    <td class="table-td">{{ $r->gpa }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

@if(auth()->user()->student)
<div class="mt-4 text-right">
    <a href="{{ route('results.student', auth()->user()->student) }}" class="btn-secondary">
        View Full Report →
    </a>
</div>
@endif

@else
<div class="card p-12 text-center">
    <svg class="w-10 h-10 text-slate-300 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
        <path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
    </svg>
    <p class="text-slate-400 text-sm">No results have been entered yet.</p>
</div>
@endif

@endsection
