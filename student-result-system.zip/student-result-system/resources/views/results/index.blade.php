@extends('layouts.app')
@section('content')
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
    <div>
        <h2 class="font-display text-xl font-semibold text-slate-800">Results</h2>
        <p class="text-sm text-slate-500 mt-0.5">{{ $results->total() }} result records</p>
    </div>
    <a href="{{ route('results.create') }}" class="btn-primary">
        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
        Enter Marks
    </a>
</div>

{{-- Filters --}}
<form method="GET" class="card p-4 mb-4 grid grid-cols-2 lg:grid-cols-4 gap-3">
    <select name="student_id" class="form-input">
        <option value="">All Students</option>
        @foreach($students as $s)
            <option value="{{ $s->id }}" {{ request('student_id') == $s->id ? 'selected' : '' }}>{{ $s->user->name }}</option>
        @endforeach
    </select>
    <select name="subject_id" class="form-input">
        <option value="">All Subjects</option>
        @foreach($subjects as $s)
            <option value="{{ $s->id }}" {{ request('subject_id') == $s->id ? 'selected' : '' }}>{{ $s->name }}</option>
        @endforeach
    </select>
    <select name="exam_type" class="form-input">
        <option value="">All Types</option>
        @foreach(['midterm','final','quiz','assignment'] as $t)
            <option value="{{ $t }}" {{ request('exam_type') == $t ? 'selected' : '' }}>{{ ucfirst($t) }}</option>
        @endforeach
    </select>
    <select name="session" class="form-input">
        <option value="">All Sessions</option>
        @foreach(['2024-25','2023-24','2022-23'] as $sess)
            <option value="{{ $sess }}" {{ request('session') == $sess ? 'selected' : '' }}>{{ $sess }}</option>
        @endforeach
    </select>
    <div class="col-span-2 lg:col-span-4 flex gap-2">
        <button type="submit" class="btn-primary">Apply Filters</button>
        @if(request()->hasAny(['student_id','subject_id','exam_type','session']))
            <a href="{{ route('results.index') }}" class="btn-secondary">Clear</a>
        @endif
    </div>
</form>

<div class="card overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-slate-50">
                <tr>
                    <th class="table-th">Student</th>
                    <th class="table-th">Subject</th>
                    <th class="table-th">Marks</th>
                    <th class="table-th">%</th>
                    <th class="table-th">Grade</th>
                    <th class="table-th">GPA</th>
                    <th class="table-th">Type</th>
                    <th class="table-th">Session</th>
                    <th class="table-th text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($results as $r)
                <tr class="table-tr">
                    <td class="table-td font-medium">{{ $r->student->user->name ?? '—' }}</td>
                    <td class="table-td">{{ $r->subject->name ?? '—' }}</td>
                    <td class="table-td">{{ $r->obtained_marks }}/{{ $r->total_marks }}</td>
                    <td class="table-td">{{ $r->percentage }}%</td>
                    <td class="table-td">
                        @php $g = $r->grade; @endphp
                        <span class="badge-{{ strtolower(str_replace('+','-plus',$g)) }}">{{ $g }}</span>
                    </td>
                    <td class="table-td">{{ $r->gpa }}</td>
                    <td class="table-td capitalize">{{ $r->exam_type }}</td>
                    <td class="table-td">{{ $r->session }}</td>
                    <td class="table-td text-right">
                        <div class="flex items-center justify-end gap-2">
                            <a href="{{ route('results.edit', $r) }}" class="text-xs text-slate-600 hover:text-slate-800 font-medium">Edit</a>
                            <form method="POST" action="{{ route('results.destroy', $r) }}"
                                  onsubmit="return confirm('Delete this result?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-xs text-red-500 hover:text-red-700 font-medium">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                    <tr><td colspan="9" class="table-td text-center text-slate-400 py-8">No results found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($results->hasPages())
        <div class="px-5 py-4 border-t border-slate-100">{{ $results->links() }}</div>
    @endif
</div>
@endsection
