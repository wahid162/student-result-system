@extends('layouts.app')
@section('content')
<div class="max-w-lg">
    <div class="mb-6">
        <h2 class="font-display text-xl font-semibold text-slate-800">Edit Result</h2>
        <p class="text-sm text-slate-500 mt-0.5">
            {{ $result->student->user->name ?? '—' }} · {{ $result->subject->name ?? '—' }}
        </p>
    </div>
    <div class="card p-6">
        <form method="POST" action="{{ route('results.update', $result) }}" novalidate>
            @csrf @method('PUT')
            <div class="space-y-4">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Obtained Marks <span class="text-slate-400">(max: {{ $result->total_marks }})</span></label>
                        <input type="number" name="obtained_marks" id="obtained_marks"
                               value="{{ old('obtained_marks', $result->obtained_marks) }}"
                               min="0" max="{{ $result->total_marks }}"
                               class="form-input {{ $errors->has('obtained_marks') ? 'form-input-error' : '' }}"
                               oninput="calcGrade({{ $result->total_marks }})" required>
                        @error('obtained_marks')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="form-label">Predicted Grade</label>
                        <div id="grade-preview" class="form-input text-center font-bold text-lg">
                            {{ $result->grade }} ({{ $result->percentage }}%)
                        </div>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Exam Type</label>
                        <select name="exam_type" class="form-input" required>
                            @foreach(['midterm','final','quiz','assignment'] as $t)
                                <option value="{{ $t }}" {{ old('exam_type', $result->exam_type) == $t ? 'selected' : '' }}>{{ ucfirst($t) }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Session</label>
                        <select name="session" class="form-input" required>
                            @foreach(['2024-25','2023-24','2022-23'] as $sess)
                                <option value="{{ $sess }}" {{ old('session', $result->session) == $sess ? 'selected' : '' }}>{{ $sess }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="submit" class="btn-primary">Update Result</button>
                    <a href="{{ route('results.index') }}" class="btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
function calcGrade(total) {
    const obtained = parseInt(document.getElementById('obtained_marks').value);
    const el = document.getElementById('grade-preview');
    if (isNaN(obtained) || obtained < 0) { el.textContent = '—'; return; }
    const pct = (obtained / total) * 100;
    let grade;
    if (pct >= 90) grade = 'A+';
    else if (pct >= 80) grade = 'A';
    else if (pct >= 70) grade = 'B';
    else if (pct >= 60) grade = 'C';
    else if (pct >= 50) grade = 'D';
    else grade = 'F';
    el.textContent = `${grade} (${pct.toFixed(1)}%)`;
}
</script>
@endsection
