<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Result extends Model
{
    use HasFactory;

    protected $fillable = [
        'student_id', 'subject_id', 'teacher_id',
        'obtained_marks', 'total_marks', 'exam_type', 'session',
    ];

    protected $appends = ['grade', 'gpa', 'percentage'];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function subject()
    {
        return $this->belongsTo(Subject::class);
    }

    public function teacher()
    {
        return $this->belongsTo(User::class, 'teacher_id');
    }

    /**
     * Auto-calculate percentage.
     */
    public function getPercentageAttribute(): float
    {
        if ($this->total_marks <= 0) return 0;
        return round(($this->obtained_marks / $this->total_marks) * 100, 2);
    }

    /**
     * Auto-calculate grade based on percentage.
     */
    public function getGradeAttribute(): string
    {
        $pct = $this->percentage;
        return match (true) {
            $pct >= 90 => 'A+',
            $pct >= 80 => 'A',
            $pct >= 70 => 'B',
            $pct >= 60 => 'C',
            $pct >= 50 => 'D',
            default    => 'F',
        };
    }

    /**
     * Auto-calculate GPA points.
     */
    public function getGpaAttribute(): float
    {
        return match ($this->grade) {
            'A+', 'A' => 4.0,
            'B'       => 3.0,
            'C'       => 2.0,
            'D'       => 1.0,
            default   => 0.0,
        };
    }

    /**
     * Static helper: calculate grade from raw values.
     */
    public static function calculateGrade(float $obtained, float $total): string
    {
        if ($total <= 0) return 'F';
        $pct = ($obtained / $total) * 100;
        return match (true) {
            $pct >= 90 => 'A+',
            $pct >= 80 => 'A',
            $pct >= 70 => 'B',
            $pct >= 60 => 'C',
            $pct >= 50 => 'D',
            default    => 'F',
        };
    }
}
