<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subject extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'code', 'class', 'total_marks', 'credit_hours'];

    public function results()
    {
        return $this->hasMany(Result::class);
    }
}
