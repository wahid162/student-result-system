<?php

namespace App\Http\Controllers;

use App\Models\Subject;
use Illuminate\Http\Request;

class SubjectController extends Controller
{
    public function index()
    {
        $subjects = Subject::withCount('results')->latest()->paginate(20);
        return view('subjects.index', [
            'subjects'         => $subjects,
            'title'            => 'Subjects — Student Result System',
            'meta_description' => 'Manage subjects and their result entries.',
        ]);
    }

    public function create()
    {
        return view('subjects.create', ['title' => 'Add Subject']);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'         => ['required', 'string', 'max:100'],
            'code'         => ['required', 'string', 'max:20', 'unique:subjects,code'],
            'class'        => ['required', 'string', 'max:20'],
            'total_marks'  => ['required', 'integer', 'min:1', 'max:1000'],
            'credit_hours' => ['required', 'integer', 'min:1', 'max:10'],
        ]);

        Subject::create($data);
        return redirect()->route('subjects.index')->with('success', 'Subject added.');
    }

    public function edit(Subject $subject)
    {
        return view('subjects.edit', ['subject' => $subject, 'title' => 'Edit Subject']);
    }

    public function update(Request $request, Subject $subject)
    {
        $data = $request->validate([
            'name'         => ['required', 'string', 'max:100'],
            'code'         => ['required', 'string', 'max:20', "unique:subjects,code,{$subject->id}"],
            'class'        => ['required', 'string', 'max:20'],
            'total_marks'  => ['required', 'integer', 'min:1', 'max:1000'],
            'credit_hours' => ['required', 'integer', 'min:1', 'max:10'],
        ]);

        $subject->update($data);
        return redirect()->route('subjects.index')->with('success', 'Subject updated.');
    }

    public function destroy(Subject $subject)
    {
        $subject->delete();
        return redirect()->route('subjects.index')->with('success', 'Subject deleted.');
    }
}
