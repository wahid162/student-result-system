<?php

namespace App\Http\Controllers;

use App\Models\Result;
use App\Models\Student;
use App\Models\Subject;
use App\Models\User;
use Illuminate\Support\Facades\Cache;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        if ($user->isStudent()) {
            $student = $user->student;
            $results = collect();

            if ($student) {
                $results = Result::with('subject')
                    ->where('student_id', $student->id)
                    ->where('session', '2024-25')
                    ->get();
            }

            $totalSubjects = $results->count();
            $avgPct        = $totalSubjects ? round($results->avg(fn($r) => $r->percentage), 1) : 0;
            $passed        = $results->filter(fn($r) => $r->grade !== 'F')->count();

            return view('dashboard.index', [
                'results'       => $results,
                'totalSubjects' => $totalSubjects,
                'avgPct'        => $avgPct,
                'passed'        => $passed,
                'title'         => 'Dashboard',
            ]);
        }

        $totalStudents = Student::count();
        $totalSubjects = Subject::count();
        $totalResults  = Result::count();
        $totalTeachers = User::where('role', 'teacher')->count();
        $recentResults = Result::with(['student.user', 'subject'])->latest()->limit(8)->get();

        return view('dashboard.index', [
            'totalStudents' => $totalStudents,
            'totalSubjects' => $totalSubjects,
            'totalResults'  => $totalResults,
            'totalTeachers' => $totalTeachers,
            'recentResults' => $recentResults,
            'title'         => 'Dashboard',
        ]);
    }
}
