<?php

namespace App\Http\Controllers;

use App\Models\Result;
use App\Models\Student;
use App\Models\Subject;
use Illuminate\Http\Request;

class ResultController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();

        if ($user->isStudent()) {
            $student = $user->student;
            $results = collect();

            if ($student) {
                $query = Result::with(['subject', 'teacher'])
                    ->where('student_id', $student->id);

                if ($request->session) {
                    $query->where('session', $request->session);
                }
                if ($request->exam_type) {
                    $query->where('exam_type', $request->exam_type);
                }

                $results = $query->latest()->get();
            }

            return view('results.my_results', compact('results'));
        }

        $query = Result::with(['student.user', 'subject', 'teacher']);

        if ($request->session)    $query->where('session',    $request->session);
        if ($request->exam_type)  $query->where('exam_type',  $request->exam_type);
        if ($request->student_id) $query->where('student_id', $request->student_id);
        if ($request->subject_id) $query->where('subject_id', $request->subject_id);

        $results  = $query->latest()->paginate(20)->withQueryString();
        $students = Student::with('user')->get();
        $subjects = Subject::all();

        return view('results.index', [
            'results'  => $results,
            'students' => $students,
            'subjects' => $subjects,
            'title'    => 'Results',
        ]);
    }

    public function create()
    {
        $students = Student::with('user')->get();
        $subjects = Subject::all();

        return view('results.create', [
            'students' => $students,
            'subjects' => $subjects,
            'title'    => 'Enter Marks',
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'student_id'     => ['required', 'exists:students,id'],
            'subject_id'     => ['required', 'exists:subjects,id'],
            'obtained_marks' => ['required', 'integer', 'min:0'],
            'exam_type'      => ['required', 'in:midterm,final,quiz,assignment'],
            'session'        => ['required', 'string', 'max:20'],
        ]);

        $subject = Subject::findOrFail($data['subject_id']);

        if ($data['obtained_marks'] > $subject->total_marks) {
            return back()->withErrors([
                'obtained_marks' => "Marks cannot exceed total ({$subject->total_marks})."
            ])->withInput();
        }

        $exists = Result::where('student_id', $data['student_id'])
            ->where('subject_id', $data['subject_id'])
            ->where('exam_type',  $data['exam_type'])
            ->where('session',    $data['session'])
            ->exists();

        if ($exists) {
            return back()->withErrors([
                'student_id' => 'Result already entered for this student/subject/type/session.'
            ])->withInput();
        }

        Result::create([
            'student_id'     => $data['student_id'],
            'subject_id'     => $data['subject_id'],
            'obtained_marks' => $data['obtained_marks'],
            'total_marks'    => $subject->total_marks,
            'exam_type'      => $data['exam_type'],
            'session'        => $data['session'],
            'teacher_id'     => auth()->id(),
        ]);

        return redirect()->route('results.index')
            ->with('success', 'Result saved! Grade calculated automatically.');
    }

    public function edit(Result $result)
    {
        $students = Student::with('user')->get();
        $subjects = Subject::all();

        return view('results.edit', [
            'result'   => $result,
            'students' => $students,
            'subjects' => $subjects,
            'title'    => 'Edit Result',
        ]);
    }

    public function update(Request $request, Result $result)
    {
        $data = $request->validate([
            'obtained_marks' => ['required', 'integer', 'min:0', 'max:' . $result->total_marks],
            'exam_type'      => ['required', 'in:midterm,final,quiz,assignment'],
            'session'        => ['required', 'string', 'max:20'],
        ]);

        $result->update($data);

        return redirect()->route('results.index')
            ->with('success', 'Result updated.');
    }

    public function destroy(Result $result)
    {
        $result->delete();

        return redirect()->route('results.index')
            ->with('success', 'Result deleted.');
    }

    public function studentReport(Student $student)
    {
        // Students can only see own report
        if (auth()->user()->isStudent()) {
            $myStudent = auth()->user()->student;
            if (!$myStudent || $myStudent->id !== $student->id) {
                abort(403);
            }
        }

        $results    = Result::with('subject')
            ->where('student_id', $student->id)
            ->where('exam_type', 'final')
            ->get();

        $total      = $results->sum('total_marks');
        $obtained   = $results->sum('obtained_marks');
        $overallPct = $total > 0 ? round(($obtained / $total) * 100, 2) : 0;
        $cgpa       = $results->count() ? round($results->avg('gpa'), 2) : 0;

        return view('results.report', [
            'student'    => $student->load('user'),
            'results'    => $results,
            'overallPct' => $overallPct,
            'cgpa'       => $cgpa,
            'title'      => 'Result Report — ' . $student->user->name,
        ]);
    }
}
