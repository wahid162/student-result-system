<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class StudentController extends Controller
{
    public function index(Request $request)
    {
        $query = Student::with('user')
            ->when($request->search, fn($q) =>
                $q->whereHas('user', fn($u) =>
                    $u->where('name', 'like', "%{$request->search}%")
                )->orWhere('roll_number', 'like', "%{$request->search}%")
            )
            ->when($request->class, fn($q) => $q->where('class', $request->class))
            ->latest();

        $students = $query->paginate(15)->withQueryString();

        return view('students.index', [
            'students'         => $students,
            'title'            => 'Students — Student Result System',
            'meta_description' => 'Manage all enrolled students and their information.',
        ]);
    }

    public function create()
    {
        return view('students.create', [
            'title' => 'Add Student',
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'          => ['required', 'string', 'max:100'],
            'email'         => ['required', 'email', 'unique:users,email'],
            'password'      => ['required', 'string', 'min:6'],
            'roll_number'   => ['required', 'string', 'unique:students,roll_number'],
            'class'         => ['required', 'string', 'max:20'],
            'section'       => ['nullable', 'string', 'max:10'],
            'date_of_birth' => ['nullable', 'date'],
            'phone'         => ['nullable', 'string', 'max:20'],
        ]);

        DB::transaction(function () use ($data) {
            $user = User::create([
                'name'     => $data['name'],
                'email'    => $data['email'],
                'password' => Hash::make($data['password']),
                'role'     => 'student',
            ]);
            Student::create([
                'user_id'       => $user->id,
                'roll_number'   => $data['roll_number'],
                'class'         => $data['class'],
                'section'       => $data['section'] ?? null,
                'date_of_birth' => $data['date_of_birth'] ?? null,
                'phone'         => $data['phone'] ?? null,
            ]);
        });

        return redirect()->route('students.index')
            ->with('success', 'Student added successfully.');
    }

    public function show(Student $student)
    {
        $student->load(['user', 'results.subject']);
        return view('students.show', [
            'student' => $student,
            'title'   => "Student: {$student->user->name}",
        ]);
    }

    public function edit(Student $student)
    {
        $student->load('user');
        return view('students.edit', [
            'student' => $student,
            'title'   => 'Edit Student',
        ]);
    }

    public function update(Request $request, Student $student)
    {
        $data = $request->validate([
            'name'          => ['required', 'string', 'max:100'],
            'class'         => ['required', 'string', 'max:20'],
            'section'       => ['nullable', 'string', 'max:10'],
            'date_of_birth' => ['nullable', 'date'],
            'phone'         => ['nullable', 'string', 'max:20'],
        ]);

        DB::transaction(function () use ($data, $student) {
            $student->user->update(['name' => $data['name']]);
            $student->update([
                'class'         => $data['class'],
                'section'       => $data['section'],
                'date_of_birth' => $data['date_of_birth'],
                'phone'         => $data['phone'],
            ]);
        });

        return redirect()->route('students.index')
            ->with('success', 'Student updated successfully.');
    }

    public function destroy(Student $student)
    {
        DB::transaction(fn() => $student->user->delete());
        return redirect()->route('students.index')
            ->with('success', 'Student deleted.');
    }
}
